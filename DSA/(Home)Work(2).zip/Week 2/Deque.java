public class Deque<E> {

    private LinkedList list;

    public Deque() {

    }

    public boolean isEmpty() {
        return first == null;
    }

    public int size() {
        return size;
    }

    public void addFirst(E data) {
		// Implement this method
    }

    public E removeFirst() {
        // Implement this method
    }

    public void addLast(E data) {
        // Implement this method
    }

    public E removeLast() {
        // Implement this method
    }
}